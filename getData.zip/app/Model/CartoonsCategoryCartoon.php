<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class CartoonsCategoryCartoon extends Model
{
    protected $table = 'cartoons_category_cartoon';
}
