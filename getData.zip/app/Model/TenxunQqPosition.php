<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class TenxunQqPosition extends Model
{
    protected $table = 'tenxun_email_position';
    
}
