<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class TenxunQq extends Model
{
    protected $table = 'tenxun_qq';
}
