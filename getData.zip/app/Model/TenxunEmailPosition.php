<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class TenxunEmailPosition extends Model
{
    protected $table = 'tenxun_email_position';
}
