<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class CartoonsCatalog extends Model
{
    protected $table = 'cartoons_catalog';

    //protected $connection = 'mysql_data';
}
