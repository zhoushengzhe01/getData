<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class CartoonsComment extends Model
{
    
    protected $table = 'cartoons_comment';
}
