<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class CartoonsImage extends Model
{
    //protected $connection = 'mysql_data';
}
