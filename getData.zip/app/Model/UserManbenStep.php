<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class UserManbenStep extends Model
{
    protected $table = 'users_manben_steps';
}
