<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class CartoonsUser extends Model
{
    protected $table = 'cartoons_user';
}
